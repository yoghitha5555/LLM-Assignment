# TripGenie – AI-Powered Travel Itinerary Generator

> **University Assignment Project**: Text Generation using Transformer Models & Few-Shot Prompt Engineering

TripGenie is a production-quality full-stack AI application that generates personalized, day-wise travel itineraries using Large Language Models (OpenAI GPT). The system incorporates **Few-Shot In-Context Prompting**, contextual dataset analytics via Pandas, visual budget breakdown with **Chart.js**, interactive geospatial mapping using **Leaflet & OpenStreetMap**, persistence with **MongoDB**, and professional PDF document export via **ReportLab**.

---

## 🌟 Key Features

- 🧠 **Few-Shot Transformer Prompt Engineering**: Utilizes structured exemplar prompts with system constraints, persona conditioning, and temperature/max-token optimizations.
- 🗓 **Day-Wise Schedule Generation**: Detailed morning, afternoon, and evening breakdowns tailored to travel styles (Solo, Couple, Family, Friends, Business).
- 💰 **Statistical Budget Estimation**: Visual donut chart and category breakdowns (Accommodation, Food, Activities, Transport, Miscellaneous) with automated cost-saving recommendations.
- 🗺 **Interactive Leaflet Maps**: Real GPS geo-coordinates for destination landmarks, attractions, and recommended hotels.
- 📄 **ReportLab PDF Export**: Direct one-click compilation into an elegant multi-page PDF travel guide.
- 💾 **MongoDB Persistence with Resilient Fallback**: Save, view, search, filter, and delete itineraries with async Motor client or automatic zero-config local storage.
- 🎨 **Modern Aesthetics**: Responsive UI with Tailwind CSS, Dark Mode switch, glassmorphism, animated loaders, and toast notifications.
- ⚡ **Zero-Failure Heuristic Engine**: Seamlessly falls back to an intelligent dataset-driven itinerary generator if external API keys or networks are unavailable during live demonstrations.

---

## 🏗 System Architecture

```
User Browser (React.js + Vite + Tailwind CSS + Leaflet + Chart.js)
                             │
                             ▼  REST API (Axios / JSON)
FastAPI Backend (Python 3.10+) ───► Lifespan & Middleware
        │
        ├──► prompt.py (Few-Shot Prompt Builder)
        │         │
        │         ▼
        ├──► llm.py (OpenAI GPT-4o-mini API / Fallback Generator)
        │
        ├──► utils.py (Pandas Dataset Query & ReportLab PDF Engine)
        │         │
        │         ├── traveler_trip.csv (Demographics & Budget splits)
        │         └── travel_recommendation.csv (Coordinates & Hotels)
        │
        └──► database.py (Motor MongoDB / JSON Fallback Cache)
```

---

## 📁 Exact Project Structure

```
TripGenie/
├── frontend/
│   ├── index.html
│   ├── package.json
│   ├── vite.config.js
│   ├── tailwind.config.js
│   ├── postcss.config.js
│   └── src/
│       ├── index.css
│       ├── main.jsx
│       ├── App.jsx
│       ├── components/
│       │   ├── Navbar.jsx
│       │   ├── Hero.jsx
│       │   ├── TripForm.jsx
│       │   ├── Loading.jsx
│       │   ├── ItineraryCard.jsx
│       │   ├── BudgetCard.jsx
│       │   ├── MapView.jsx
│       │   └── Footer.jsx
│       └── pages/
│           ├── Home.jsx
│           ├── Result.jsx
│           ├── SavedTrips.jsx
│           ├── About.jsx
│           └── NotFound.jsx
├── backend/
│   ├── app.py
│   ├── database.py
│   ├── models.py
│   ├── routes.py
│   ├── prompt.py
│   ├── llm.py
│   ├── utils.py
│   ├── requirements.txt
│   ├── .env.example
│   ├── .env
│   └── datasets/
│       ├── traveler_trip.csv
│       └── travel_recommendation.csv
├── datasets/
│   ├── traveler_trip.csv
│   └── travel_recommendation.csv
└── README.md
```

---

## 🛠 Tech Stack

### Frontend
- **Framework**: React.js 18 + Vite
- **Styling**: Tailwind CSS + Glassmorphism tokens
- **Routing**: React Router DOM v6
- **Icons**: Lucide React
- **HTTP Client**: Axios
- **Maps**: Leaflet + OpenStreetMap tiles
- **Charts**: Chart.js + `react-chartjs-2`
- **Feedback**: `react-hot-toast` + `canvas-confetti`

### Backend
- **Framework**: FastAPI (Async Python)
- **Validation**: Pydantic v2
- **Server**: Uvicorn
- **AI Integration**: OpenAI GPT API (`gpt-4o-mini`)
- **PDF Engine**: ReportLab 4.x
- **Data Analytics**: Pandas
- **Database**: MongoDB (Async Motor driver) + Local JSON fallback

---

## 🚀 Installation & Setup Guide

### 1. Prerequisites
- **Node.js** (v18 or higher)
- **Python** (v3.10 or higher)
- **MongoDB** (Optional – runs locally at `localhost:27017` or uses automatic fallback)

---

### 2. Backend Setup

1. Open a terminal and navigate to the backend directory:
   ```bash
   cd TripGenie/backend
   ```

2. Create and activate a Python virtual environment:
   ```bash
   # Windows
   python -m venv venv
   .\venv\Scripts\activate

   # macOS / Linux
   python3 -m venv venv
   source venv/bin/activate
   ```

3. Install required Python packages:
   ```bash
   pip install -r requirements.txt
   ```

4. Configure environment variables in `TripGenie/backend/.env`:
   ```env
   PORT=8000
   HOST=0.0.0.0
   OPENAI_API_KEY=your_openai_api_key_here
   OPENAI_MODEL=gpt-4o-mini
   MONGODB_URL=mongodb://localhost:27017
   DATABASE_NAME=tripgenie_db
   ```
   *(Note: If you do not have an OpenAI API key or MongoDB installed, the application will automatically engage the heuristic dataset fallback engine so the demo will work 100% without crashing!)*

5. Start the FastAPI server:
   ```bash
   uvicorn app:app --reload --port 8000
   ```
   Backend will be running at: `http://localhost:8000` (Interactive Swagger Docs: `http://localhost:8000/docs`)

---

### 3. Frontend Setup

1. Open a second terminal and navigate to the frontend directory:
   ```bash
   cd TripGenie/frontend
   ```

2. Install npm dependencies:
   ```bash
   npm install
   ```

3. Start the Vite development server:
   ```bash
   npm run dev
   ```

4. Open your browser and navigate to:
   ```
   http://localhost:5173
   ```

---

## 📡 Backend REST API Reference

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/health` | Server and subsystem health status |
| `POST` | `/generate` | Generates day-wise itinerary, budget distribution & map points |
| `POST` | `/save` | Persists itinerary to MongoDB database |
| `GET` | `/trips` | Retrieves saved trips with search and style filtering |
| `GET` | `/trips/{id}` | Retrieves a single saved trip by ID |
| `DELETE` | `/trips/{id}` | Removes a saved trip from the database |
| `POST` | `/export-pdf` | Streams a styled ReportLab PDF file |
| `GET` | `/trips/{id}/pdf` | Downloads PDF directly for a saved trip ID |
| `GET` | `/destinations/popular` | Returns popular destinations and starter templates |

---

## 🧠 Few-Shot Prompt Engineering Details

Few-Shot Prompting introduces in-context input/output demonstrations to the Transformer before inference:

```text
[System Prompt] -> Authoritative AI Travel Concierge
[Few-Shot Example 1] -> Input: Goa Beach 3 Days -> Output: Check-in, Calangute, Baga, Fort Aguada
[Few-Shot Example 2] -> Input: Ooty Nature 2 Days -> Output: Botanical Garden, Tea Factory, Lake
[User Query] -> Destination: {destination}, Budget: {budget}, Days: {days}, Style: {travelStyle}
[Constraints] -> Return Markdown + JSON schema for Map/Chart rendering
```

---

## 📸 Screenshots Overview

1. **Hero & Interactive Form**: Modern gradient header with quick-start destination chips and multi-select interest checkboxes.
2. **AI Loading Screen**: Multi-step animated progress loader detailing the Transformer reasoning phases.
3. **Master Itinerary View**: Expandable daily timeline cards with morning, afternoon, and evening experiences.
4. **Interactive Map**: OpenStreetMap Leaflet integration with custom markers for attractions and hotels.
5. **Budget Estimation Card**: Chart.js Doughnut chart and progress bars with savings tips.
6. **Saved Trips Dashboard**: Searchable and filterable database grid with one-click PDF downloads.
7. **ReportLab PDF Export**: High-resolution branded travel itinerary document.

---

## 🎓 Academic Citation

```bibtex
@misc{tripgenie2026,
  title={TripGenie: AI-Powered Travel Itinerary Generator using Few-Shot Transformer Prompting},
  author={University Student Project},
  year={2026},
  howpublished={\url{https://github.com/your-username/TripGenie}}
}
```
